import React from 'react'
import './Loader.css'

const Loader = () => {
  return (
    <div className="loaderDiv">
      <section className="loader"></section>
    </div>
  )
}

export default Loader
