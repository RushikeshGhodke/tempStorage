import React, { useEffect } from 'react'
import logo from '../../../assets/aakarlogo.svg'
import './Navbar.css'
import { FiUser } from 'react-icons/fi'

const Navbar = () => {
  const googleTranslateElementInit = () => {
    new window.google.translate.TranslateElement(
      {
        pageLanguage: 'en',
        includedLanguages: 'hi,ta,te,kn,ml,mr,bn,gu,pa,ur,en',
        autoDisplay: false,
      },
      'google_translate_element'
    )
  }
  // useEffect(() => {
  //   if (!window.googleTranslateElementInit) {
  //     var addScript = document.createElement('script')
  //     addScript.setAttribute(
  //       'src',
  //       '//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit'
  //     )
  //     document.body.appendChild(addScript)
  //     window.googleTranslateElementInit = googleTranslateElementInit
  //   }
  // }, [])
  return (
    <nav id="navbar">
      <img src={logo} alt="Aakar Dies & Moulds" />
      <div className="navDiv">
        <div id="google_translate_element"></div>
        <FiUser className="user-icon" color="white" size={20} />
      </div>
    </nav>
  )
}

export default Navbar
