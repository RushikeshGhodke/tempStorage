import React, { useMemo, useState, useRef, Suspense } from 'react'
// import './Tables.css'
import { useTable, useSortBy, usePagination } from 'react-table'
import { formatDate } from '../functions/formatDate'
import { GrNext } from 'react-icons/gr'
import { GrPrevious } from 'react-icons/gr'
import { Link } from 'react-router-dom'
import { DownloadTableExcel } from 'react-export-table-to-excel'
import Loader from '../loader/Loader'
import { FiEdit2 } from 'react-icons/fi'
import { RiDeleteBinLine } from 'react-icons/ri'
import { FaSort, FaSortUp, FaSortDown } from 'react-icons/fa'
import { useDispatch } from 'react-redux'
import { deleteProject, deleteStage } from '../../../features/projectSlice'

const Tables = ({ columns, rows, name, update }) => {
  const [keyword, setKeyword] = useState('')
  const tableRef = useRef(null)
  const dispatch = useDispatch()

  const formattedRows = useMemo(
    () =>
      rows.map((row, index) => ({
        ...row,
        srNo: index + 1,
        startDate: formatDate(row.startDate),
        endDate: formatDate(row.endDate),
      })),
    [rows]
  )

  const filteredRows = useMemo(() => {
    return formattedRows.filter((row) =>
      Object.values(row).some((val) =>
        String(val).toLowerCase().includes(keyword.toLowerCase())
      )
    )
  }, [formattedRows, keyword])

  const {
    getTableProps,
    getTableBodyProps,
    headerGroups,
    page,
    prepareRow,
    nextPage,
    previousPage,
    state: { pageIndex },
    pageCount,
    gotoPage,
  } = useTable(
    {
      columns,
      data: filteredRows,
      initialState: { pageSize: 10 },
    },
    useSortBy,
    usePagination
  )

  return (
    <Suspense fallback={<Loader />}>
      <section className="getProjects" style={{ width: '90%' }}>
        <div className="containerSearchAndPage">
          <div className="searchExport">
            <input
              type="search"
              className="search"
              name="searchProject"
              value={keyword}
              placeholder="Search..."
              onChange={(e) => {
                setKeyword(e.target.value)
              }}
            />
            <DownloadTableExcel
              filename={name}
              sheet="users"
              currentTableRef={tableRef.current}
              className="export"
            >
              <button> Export excel </button>
            </DownloadTableExcel>
          </div>
          <div className="paginationContainer">
            <button disabled={pageIndex === 0} onClick={() => gotoPage(0)}>
              First
            </button>
            <button disabled={pageIndex === 0} onClick={previousPage}>
              <GrPrevious />
            </button>
            <span>
              {pageIndex + 1} of {pageCount}
            </span>
            <button disabled={pageIndex === pageCount - 1} onClick={nextPage}>
              <GrNext />
            </button>
            <button
              disabled={pageIndex === pageCount - 1}
              onClick={() => gotoPage(pageCount - 1)}
            >
              Last
            </button>
          </div>
        </div>
        <div className="table-container">
          <table ref={tableRef} {...getTableProps()}>
            <thead>
              {headerGroups.map((hg, i) => (
                <tr key={i} {...hg.getHeaderGroupProps()}>
                  {hg.headers.map((header, i) => (
                    <th
                      key={i}
                      {...header.getHeaderProps(header.getSortByToggleProps())}
                    >
                      <div className="header">
                        {header.render('Header')}
                        <span className="sortIcon">
                          {header.isSorted ? (
                            header.isSortedDesc ? (
                              <FaSortUp />
                            ) : (
                              <FaSortDown />
                            )
                          ) : (
                            <FaSort style={{ opacity: '0.5' }} />
                          )}
                        </span>
                      </div>
                    </th>
                  ))}
                </tr>
              ))}
            </thead>
            <tbody {...getTableBodyProps()}>
              {page.map((row, i) => {
                prepareRow(row)
                return (
                  <tr {...row.getRowProps()} className="row">
                    {row.cells.map((cell, i) => {
                      const cellProps = cell.getCellProps()
                      const statusClass =
                        cell.column.id === 'projectStatus'
                          ? cell.value === 'Completed'
                            ? 'completed'
                            : cell.value === 'Overdue'
                            ? 'overdue'
                            : 'pending'
                          : ''
                      return (
                        <td key={i} {...cellProps}>
                          <Link
                            to={`/myProject/${row.cells[1].value}`}
                            className={`link + " " + ${statusClass}`}
                          >
                            {cell.render('Cell')}
                          </Link>
                        </td>
                      )
                    })}
                    <div className="options">
                      <Link to={`/${update}/${row.cells[1].value}`}>
                        <FiEdit2 className="opt" />
                      </Link>
                      <>
                        <RiDeleteBinLine
                          className="opt"
                          onClick={() =>
                            name == 'All Projects'
                              ? dispatch(deleteProject(row.cells[1].value))
                              : dispatch(deleteStage(row.cells[1].value))
                          }
                        />
                      </>
                    </div>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>
      </section>
    </Suspense>
  )
}

export default Tables
