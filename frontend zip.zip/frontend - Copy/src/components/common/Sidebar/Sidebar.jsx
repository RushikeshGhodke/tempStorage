import './Sidebar.css'
import { FiMenu, FiClipboard, FiBriefcase, FiUser } from 'react-icons/fi'
import { Link } from 'react-router-dom'
const Sidebar = () => {
  return (
    <div className="sidebar">
      <FiMenu className="menu-icon" size={24} color="white" />
      <div className="menu">
        <Link to={'/'} className="icon-container">
          <FiClipboard className="icon" size={24} color="white" />
          <span className="menu-text">Projects</span>
        </Link>
        <div className="icon-container">
          <FiBriefcase className="icon" size={24} color="white" />
          <span className="menu-text">Departments</span>
        </div>
        <div className="icon-container">
          <FiUser className="icon" size={24} color="white" />
          <span className="menu-text">Employees</span>
        </div>
      </div>
    </div>
  )
}

export default Sidebar
