import React, { useState } from 'react'
import './AddProject.css'
import getTodayDate from '../../common/functions/getTodayDate'
import ProjectForm from '../common/ProjectForm'
import { FaRegArrowAltCircleLeft } from 'react-icons/fa'
import { FiSave } from 'react-icons/fi'
import { useDispatch, useSelector } from 'react-redux'
import { addProject } from '../../../features/projectSlice.js'
import AddStage from '../AddStage/AddStage'
import { useNavigate } from 'react-router-dom'
import { toast } from 'react-toastify'
import 'react-toastify/dist/ReactToastify.css'

const AddProject = () => {
  const dispatch = useDispatch()
  const navigate = useNavigate()
  const { status } = useSelector((state) => state.projects)

  const [inputValues, setInputValues] = useState({
    projectNumber: '',
    companyName: '',
    dieName: '',
    dieNumber: '',
    projectStatus: '',
    startDate: getTodayDate(), // Ensure this returns a dayjs object
    endDate: null,
    projectType: '',
    projectPOLink: '',
    projectDesignDocLink: '',
    projectCreatedBy: 'Krishna Magar',
  })

  const [stages, setStages] = useState([
    {
      projectNumber: inputValues.projectNumber,
      stageName: '',
      startDate: getTodayDate(),
      endDate: null,
      owner: '',
      machine: '',
      duration: '',
      seqPrevStage: null,
      createdBy: 'Rushikesh Ghodke',
    },
  ])

  const handleSave = (e) => {
    e.preventDefault()

    const projectData = {
      ...inputValues,
      stages,
    }

    dispatch(addProject(projectData))

    setInputValues({
      projectNumber: '',
      companyName: '',
      dieName: '',
      dieNumber: '',
      projectStatus: '',
      startDate: getTodayDate(),
      endDate: null,
      projectType: '',
      projectPOLink: '',
      projectDesignDocLink: '',
      projectCreatedBy: 'John Doe',
    })

    setStages([
      {
        projectNumber: '',
        stageName: '',
        startDate: getTodayDate(),
        endDate: null,
        owner: '',
        machine: '',
        duration: '',
        seqPrevStage: null,
        createdBy: 'Rushikesh Ghodke',
      },
    ])

    // Navigate back or show a success message
    // navigate('/')
    toast.success('Project saved successfully!')
  }

  return (
    <section className="addProject">
      <form className="addForm" onSubmit={handleSave}>
        <div className="beforeForm">
          <p>
            <FaRegArrowAltCircleLeft
              className="back"
              onClick={() => navigate('/')}
            />
            <span>
              Dashboard <span>/</span>
            </span>
            Add Project
          </p>
          <button type="submit" className="save">
            <FiSave />
            <p>Save project</p>
          </button>
        </div>
        <div className="formDiv">
          <ProjectForm
            inputValues={inputValues}
            setInputValues={setInputValues}
          />
          <AddStage
            stages={stages}
            setStages={setStages}
            setInputValues={setInputValues}
          />
        </div>
      </form>
    </section>
  )
}

export default AddProject
