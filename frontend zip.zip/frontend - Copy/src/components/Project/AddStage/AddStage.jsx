import React, { useEffect, useMemo } from 'react'

import { FiPlusCircle } from 'react-icons/fi'
import { RiDeleteBinLine } from 'react-icons/ri'
import './AddStage.css'
import getTodayDate from '../../common/functions/getTodayDate'
import { differenceInDays, setDate } from 'date-fns'
import stagesNames from '../../common/data'
import TextField from '@mui/material/TextField'
import Autocomplete from '@mui/material/Autocomplete'
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs'
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider'
import { DatePicker } from '@mui/x-date-pickers/DatePicker'
import dayjs from 'dayjs'
import {
  duration,
  FormControl,
  InputLabel,
  MenuItem,
  Select,
} from '@mui/material'

const AddStage = ({ stages, setStages, setInputValues }) => {
  const handleAddStage = () => {
    const startDate =
      stages.length > 0 ? stages[stages.length - 1].endDate : getTodayDate()
    setStages([
      ...stages,
      {
        stageName: '',
        startDate: startDate,
        endDate: '',
        owner: '',
        machine: '',
        duration: '',
        seqPrevStage:
          stages.length > 0 ? stages[stages.length - 1].stageId : null,
        createdBy: 'John Doe',
      },
    ])
  }

  const handleDeleteStage = (index) => {
    const delStage = [...stages]
    delStage.splice(index, 1)
    setStages(delStage)
  }
  const handleChange = (e, i) => {
    const { name, value } = e.target
    const list = [...stages]
    list[i][name] = value
    console.log(name)

    if (name === 'startDate' || name === 'endDate') {
      list[i].duration =
        list[i].endDate && list[i].startDate
          ? differenceInDays(
              new Date(list[i].endDate),
              new Date(list[i].startDate)
            )
          : 0
    }

    if (name === 'endDate' && list[i].endDate < list[i].startDate) {
      list[i].endDate = ''
      list[i].duration = 0
    }
    setStages(list)
  }
  const handleDurationChange = (e, i) => {
    const { name, value } = e.target
    const list = [...stages]
    list[i][name] = value

    if (name === 'duration') {
      const startDate = new Date(list[i].startDate)
      const durationInDays = parseInt(value, 10)

      if (!isNaN(durationInDays) && durationInDays >= 0) {
        const endDate = new Date(startDate)
        endDate.setDate(startDate.getDate() + durationInDays)
        list[i].endDate = endDate.toISOString().split('T')[0]
      } else {
        list[i].endDate = ''
      }
    }

    const handleDateChange = (date, fieldName) => {
      setInputValues((prevValues) => ({
        ...prevValues,
        [fieldName]: date ? date.toISOString() : null,
      }))
    }
    if (value >= 0) setStages(list)
  }

  const options = stagesNames

  return (
    <>
      <div className="schedule">
        <p>Schedule</p>
        <button className="addStageBtn" onClick={handleAddStage}>
          <FiPlusCircle />
          <p>Add Stage</p>
        </button>
      </div>
      <div className="stages">
        {stages.length > 0 ? (
          stages.map((stage, index) => (
            <div key={index} className="stageDetails">
              <p className="serialNo">{index + 1}.</p>
              <div className="addForm" style={{ margin: '0' }}>
                <Autocomplete
                  options={options}
                  sx={{ width: 300 }}
                  renderInput={(params) => (
                    <TextField
                      label="Stage name"
                      variant="outlined"
                      sx={{
                        width: '300px',
                        '& .MuiOutlinedInput-root': {
                          height: '50px',
                        },
                        '& .MuiFormLabel-root': {
                          height: '50px',
                          lineHeight: '50px',
                          top: '-15px',
                        },
                      }}
                      InputProps={{ sx: { borderRadius: 2 } }}
                      name="stageName"
                      value={stage.stageName}
                      onChange={(e) => handleChange(e, index)}
                      required
                    />
                  )}
                />

                <TextField
                  label="Owner"
                  variant="outlined"
                  sx={{
                    width: '300px',
                    '& .MuiOutlinedInput-root': {
                      height: '50px',
                    },
                    '& .MuiFormLabel-root': {
                      height: '50px',
                      lineHeight: '50px',
                      top: '-15px',
                    },
                  }}
                  InputProps={{ sx: { borderRadius: 2 } }}
                  name="owner"
                  value={stage.owner}
                  onChange={(e) => handleChange(e, index)}
                  required
                />
                <TextField
                  label="Machine"
                  variant="outlined"
                  sx={{
                    width: '300px',
                    '& .MuiOutlinedInput-root': {
                      height: '50px',
                    },
                    '& .MuiFormLabel-root': {
                      height: '50px',
                      lineHeight: '50px',
                      top: '-15px',
                    },
                  }}
                  InputProps={{ sx: { borderRadius: 2 } }}
                  name="machine"
                  value={stage.machine}
                  onChange={(e) => handleChange(e, index)}
                />

                <LocalizationProvider dateAdapter={AdapterDayjs}>
                  <DatePicker
                    label="Start Date"
                    value={dayjs(stage.startDate)}
                    onChange={(date) => handleDateChange(date, 'endDate')}
                    renderInput={(params) => (
                      <TextField
                        {...params}
                        sx={{
                          width: '300px',
                          '& .MuiInputBase-input': {
                            height: '50px',
                            fontSize: '1rem',
                          },
                        }}
                      />
                    )}
                    required
                  />
                </LocalizationProvider>
                <LocalizationProvider dateAdapter={AdapterDayjs}>
                  <DatePicker
                    label="End Date"
                    value={dayjs(stage.endDate)}
                    onChange={(date) => handleDateChange(date, 'endDate')}
                    renderInput={(params) => (
                      <TextField
                        {...params}
                        sx={{
                          width: '300px',
                          '& .MuiInputBase-input': {
                            height: '50px',
                            fontSize: '1rem',
                          },
                        }}
                      />
                    )}
                    required
                  />
                </LocalizationProvider>
                <TextField
                  label="Duration"
                  variant="outlined"
                  sx={{
                    width: '300px',
                    '& .MuiOutlinedInput-root': {
                      height: '50px',
                    },
                    '& .MuiFormLabel-root': {
                      height: '50px',
                      lineHeight: '50px',
                      top: '-15px',
                    },
                  }}
                  InputProps={{ sx: { borderRadius: 2 } }}
                  name="duration"
                  value={stage.duration}
                  onChange={(e) => handleDurationChange(e, index)}
                  required
                />
              </div>

              <div className="option-icons">
                <button
                  className="option"
                  onClick={() => handleDeleteStage(index)}
                >
                  <RiDeleteBinLine />
                </button>
              </div>
            </div>
          ))
        ) : (
          <p className="noStageAdded">No stage added!</p>
        )}
      </div>
    </>
  )
}

export default AddStage
