import React from 'react'
import '../AddProject/AddProject.css'
import { FaRegArrowAltCircleLeft } from 'react-icons/fa'
import { FiSave } from 'react-icons/fi'
import { LuUpload } from 'react-icons/lu'
import { useDispatch } from 'react-redux'
import { addProject } from '../../../features/projectSlice.js'
import AddStage from '../AddStage/AddStage'
import TextField from '@mui/material/TextField'
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs'
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider'
import { DatePicker } from '@mui/x-date-pickers/DatePicker'
import dayjs from 'dayjs'
import { FormControl, InputLabel, MenuItem, Select } from '@mui/material'

const SubstageForm = ({ inputValues, setInputValues }) => {
  const handleChange = (e) => {
    const { name, value } = e.target
    setInputValues((prevValues) => ({
      ...prevValues,
      [name]: value,
    }))
  }

  const handleDateChange = (date, fieldName) => {
    setInputValues((prevValues) => ({
      ...prevValues,
      [fieldName]: date,
    }))
  }

  const {
    stageName,
    owner,
    machine,
    startDate,
    endDate,
    duration,
    seqPrevStage,
    createdBy,
  } = inputValues

  return (
    <>
      <h2>Project details</h2>
      <div className="container">
        <TextField
          label="Stage name"
          variant="outlined"
          sx={{
            width: '300px',
            '& .MuiOutlinedInput-root': {
              height: '50px',
            },
            '& .MuiFormLabel-root': {
              height: '50px',
              lineHeight: '50px',
              top: '-15px',
            },
          }}
          InputProps={{ sx: { borderRadius: 2 } }}
          name="stageName"
          value={stageName}
          onChange={handleChange}
          required
        />
        <TextField
          label="Stage owner"
          variant="outlined"
          sx={{
            width: '300px',
            '& .MuiOutlinedInput-root': {
              height: '50px',
            },
            '& .MuiFormLabel-root': {
              height: '50px',
              lineHeight: '50px',
              top: '-15px',
            },
          }}
          InputProps={{ sx: { borderRadius: 2 } }}
          name="owner"
          value={owner}
          onChange={handleChange}
          required
        />
        <TextField
          label="Machine"
          variant="outlined"
          sx={{
            width: '300px',
            '& .MuiOutlinedInput-root': {
              height: '50px',
            },
            '& .MuiFormLabel-root': {
              height: '50px',
              lineHeight: '50px',
              top: '-15px',
            },
          }}
          InputProps={{ sx: { borderRadius: 2 } }}
          name="machine"
          value={machine}
          onChange={handleChange}
          required
        />
        <TextField
          label="Die number"
          variant="outlined"
          sx={{
            width: '300px',
            '& .MuiOutlinedInput-root': {
              height: '50px',
            },
            '& .MuiFormLabel-root': {
              height: '50px',
              lineHeight: '50px',
              top: '-15px',
            },
          }}
          name="dieNumber"
          value={inputValues.dieNumber}
          onChange={handleChange}
          required
        />

        <LocalizationProvider dateAdapter={AdapterDayjs}>
          <DatePicker
            label="Start Date"
            value={dayjs(inputValues.startDate)} // Ensure value is a valid Dayjs object
            onChange={(date) => handleDateChange(date, 'startDate')}
            renderInput={(params) => (
              <TextField
                {...params}
                sx={{
                  width: '300px',
                  '& .MuiInputBase-input': { height: '50px', fontSize: '1rem' },
                }}
              />
            )}
            required
          />
        </LocalizationProvider>

        <LocalizationProvider dateAdapter={AdapterDayjs}>
          <DatePicker
            label="End Date"
            value={dayjs(inputValues.endDate)} // Ensure value is a valid Dayjs object
            onChange={(date) => handleDateChange(date, 'endDate')}
            renderInput={(params) => (
              <TextField
                {...params}
                sx={{
                  width: '300px',
                  '& .MuiInputBase-input': { height: '50px', fontSize: '1rem' },
                }}
              />
            )}
            required
          />
        </LocalizationProvider>
        <TextField
          label="Duration"
          variant="outlined"
          sx={{
            width: '300px',
            '& .MuiOutlinedInput-root': {
              height: '50px',
            },
            '& .MuiFormLabel-root': {
              height: '50px',
              lineHeight: '50px',
              top: '-15px',
            },
          }}
          name="duration"
          value={duration}
          onChange={handleChange}
          required
        />
        {/* <FormControl>
          <InputLabel id="status-label">Project Status</InputLabel>
          <Select
            sx={{ width: '200px' }}
            labelId="status-label"
            id="status"
            name="projectStatus"
            value={projectStatus}
            onChange={handleChange}
            required
            label="Project Status"
          >
            <MenuItem value="">
              <em>None</em>
            </MenuItem>
            <MenuItem value="Pending">Pending</MenuItem>
            <MenuItem value="Completed">Completed</MenuItem>
            <MenuItem value="Overdue">Overdue</MenuItem>
          </Select>
        </FormControl> */}
      </div>
    </>
  )
}

export default SubstageForm
