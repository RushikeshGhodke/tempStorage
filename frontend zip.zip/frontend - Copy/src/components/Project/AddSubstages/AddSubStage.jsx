import React, { useState, useEffect, useMemo } from 'react'
import SubstageForm from './SubstageForm'
import { useDispatch, useSelector } from 'react-redux'
import { useNavigate, useParams } from 'react-router-dom'
import { FaRegArrowAltCircleLeft } from 'react-icons/fa'
import { FiSave } from 'react-icons/fi'
import AddStage from '../AddStage/AddStage'

const AddSubStage = () => {
  const params = useParams()
  const pNo = params.id
  const dispatch = useDispatch()

  const { project = {}, stages = [] } = useSelector((state) => state.projects)

  const [inputValues, setInputValues] = useState({
    projectNumber: '',
    companyName: '',
    dieName: '',
    dieNumber: '',
    projectStatus: '',
    startDate: '',
    endDate: '',
    projectType: '',
    projectPOLink: '',
    projectDesignDocLink: '',
    projectCreatedBy: 2,
  })
  const navigate = useNavigate('/')
  const [stage, setStage] = useState([])
  const [originalStages, setOriginalStages] = useState([])

  useEffect(() => {
    dispatch(fetchProjectById(pNo))
    dispatch(fetchStages(pNo))
    dispatch(fetchProjects())
  }, [dispatch, pNo])

  const currStages = useMemo(() => {
    return stages && stages.filter((stage) => stage.historyOf == null)
  }, [stages])

  useEffect(() => {
    if (project) {
      setInputValues({
        ...project,
        startDate: formatDate(project.startDate),
        endDate: formatDate(project.endDate),
      })
    }
  }, [project])

  useEffect(() => {
    if (currStages.length > 0) {
      setStage(
        currStages.map((s) => ({
          ...s,
          startDate: formatDate(s.startDate),
          endDate: formatDate(s.endDate),
        }))
      )
      setOriginalStages(
        currStages.map((s) => ({
          ...s,
          startDate: formatDate(s.startDate),
          endDate: formatDate(s.endDate),
        }))
      )
    }
  }, [currStages])

  const handleSave = (e) => {
    e.preventDefault()

    dispatch(updateProject({ id: pNo, data: inputValues }))

    stage.forEach((s, index) => {
      const originalStage = originalStages[index]
      console.log({ s: { ...s } })
      console.log({ originalStage: { ...originalStage } })

      if (hasChanges(s, originalStage)) {
        dispatch(updateStage({ ...s, projectNumber: pNo }))
      }
    })

    navigate('/')
  }

  const hasChanges = (stage, originalStage) => {
    return Object.keys(stage).some((key) => stage[key] !== originalStage[key])
  }

  return (
    <>
      <section className="addProject">
        <form className="addForm" onSubmit={handleSave}>
          <div className="beforeForm">
            <p>
              <FaRegArrowAltCircleLeft
                className="back"
                onClick={() => history.back()}
              />
              <span>
                Dashboard <span>/</span>
              </span>
              Update Stage
            </p>
            <button type="submit" className="save">
              <FiSave />
              <p>Save stage</p>
            </button>
          </div>
          <div className="formDiv">
            <SubstageForm
              inputValues={inputValues}
              setInputValues={setInputValues}
            />
            <AddStage stages={stage} setStages={setStage} />
          </div>
        </form>
      </section>
    </>
  )
}

export default AddSubStage
