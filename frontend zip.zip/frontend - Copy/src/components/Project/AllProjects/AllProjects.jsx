import React, { useEffect, useMemo, useState } from 'react'
import Infocard from '../Infocard/Infocard.jsx'
import { Link } from 'react-router-dom'
import {
  FiPlusCircle,
  FiClipboard,
  FiBell,
  FiAlertCircle,
  FiCheckCircle,
} from 'react-icons/fi'
import { useDispatch, useSelector } from 'react-redux'
import { fetchProjects } from '../../../features/projectSlice.js'
import TableComponent from '../../../Table/TableComponent.jsx'
import './AllProjects.css'

const columns = [
  {
    label: 'Project Number',
    id: 'projectNumber',
  },
  {
    label: 'Company Name',
    id: 'companyName',
  },
  {
    label: 'Die Name',
    id: 'dieName',
  },
  {
    label: 'Status',
    id: 'projectStatus',
  },
  {
    label: 'Start Date',
    id: 'startDate',
  },
  {
    label: 'End Date',
    id: 'endDate',
  },
]

const AllProjects = () => {
  const dispatch = useDispatch()
  const { projects, status, error, loading } = useSelector(
    (state) => state.projects
  )
  const [projectsList, setProjectsList] = useState([])

  useEffect(() => {
    if (status === 'idle') {
      dispatch(fetchProjects())
    }
    setProjectsList(projects) // This will run after the data is fetched
  }, [dispatch, status, projects])

  const overdueProjects = useMemo(() => {
    return projects.filter((op) => op.projectStatus === 'Overdue')
  }, [projects])

  const pendingProjects = useMemo(() => {
    return projects.filter((op) => op.projectStatus === 'Pending')
  }, [projects])

  const completedProjects = useMemo(() => {
    return projects.filter((op) => op.projectStatus === 'Completed')
  }, [projects])

  return (
    <div className="allProject">
      <section className="info-section">
        <div className="info-tab">
          <div onClick={() => setProjectsList(projects)}>
            <Infocard
              icon={<FiClipboard />}
              number={projects.length}
              text={'All Projects'}
              className={`infoCard ${
                projectsList === projects ? 'selected' : ''
              }`}
            />
          </div>
          <div onClick={() => setProjectsList(overdueProjects)}>
            <Infocard
              icon={<FiBell />}
              number={overdueProjects.length}
              text={'Overdue'}
              className={`infoCard ${
                projectsList === overdueProjects ? 'selected' : ''
              }`}
            />
          </div>
          <div onClick={() => setProjectsList(pendingProjects)}>
            <Infocard
              icon={<FiAlertCircle />}
              number={pendingProjects.length}
              text={'Pending'}
              className={`infoCard ${
                projectsList === pendingProjects ? 'selected' : ''
              }`}
            />
          </div>
          <div onClick={() => setProjectsList(completedProjects)}>
            <Infocard
              icon={<FiCheckCircle />}
              number={completedProjects.length}
              text={'Completed'}
              className={`infoCard ${
                projectsList === completedProjects ? 'selected' : ''
              }`}
            />
          </div>
        </div>
        <Link to={'/addProject'} style={{ textDecoration: 'none' }}>
          <button className="addStageBtn">
            <FiPlusCircle />
            <p>Add project</p>
          </button>
        </Link>
      </section>
      <TableComponent
        rows={projectsList}
        columns={columns}
        linkBasePath={'myProject'}
        optionLinkBasePath={'updateProject'}
      />
    </div>
  )
}

export default AllProjects
