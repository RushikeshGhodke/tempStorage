import React, { useEffect, useState } from 'react'
import '../AddProject/AddProject.css'
import { FaRegArrowAltCircleLeft } from 'react-icons/fa'
import { useDispatch, useSelector } from 'react-redux'
import {
  fetchProjectById,
  fetchProjects,
  fetchStages,
} from '../../../features/projectSlice.js'
import { useNavigate, useParams } from 'react-router-dom'

import TextField from '@mui/material/TextField'
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs'
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider'
import { DatePicker } from '@mui/x-date-pickers/DatePicker'
import dayjs from 'dayjs'
import { FormControl, InputLabel, MenuItem, Select } from '@mui/material'
import { LuUpload } from 'react-icons/lu'

import TableComponent from '../../../Table/TableComponent.jsx'

const columns = [
  {
    label: 'Stage Name',
    id: 'stageName',
  },
  {
    label: 'Owner',
    id: 'owner',
  },
  {
    label: 'Start Date',
    id: 'startDate',
  },
  {
    label: 'End Date',
    id: 'endDate',
  },
  {
    label: 'Machine',
    id: 'machine',
  },
  {
    label: 'Duration',
    id: 'duration',
  },
  {
    label: 'Created By',
    id: 'createdBy',
  },
]

const MyProject = () => {
  const params = useParams()
  const pNo = params.id
  const dispatch = useDispatch()
  const { project = {}, stages = [] } = useSelector((state) => state.projects)
  const navigate = useNavigate()

  useEffect(() => {
    dispatch(fetchProjectById(pNo))
    dispatch(fetchStages(pNo))
    dispatch(fetchProjects())
  }, [dispatch, pNo])

  const {
    projectNumber,
    companyName,
    dieName,
    dieNumber,
    projectStatus,
    startDate,
    endDate,
    projectType,
    projectPOLink,
    projectDesignDocLink,
    projectCreatedBy,
  } = project

  return (
    <section className="addProject">
      <div className="addForm">
        <div className="beforeForm">
          <p>
            <FaRegArrowAltCircleLeft
              className="back"
              onClick={() => history.back()}
            />
            <span>
              Dashboard <span>/</span>
            </span>
            My Project
          </p>
        </div>
        <div className="formDiv">
          <h2>Project details</h2>
          <form className="addForm">
            <div className="container">
              <TextField
                label="Company name"
                variant="outlined"
                sx={{
                  width: '300px',
                  '& .MuiOutlinedInput-root': { height: '50px' },
                }}
                InputProps={{ sx: { borderRadius: 2 } }}
                name="companyName"
                value={companyName}
                required
              />
              <TextField
                label="Project number"
                variant="outlined"
                sx={{
                  width: '300px',
                  '& .MuiOutlinedInput-root': { height: '50px' },
                }}
                InputProps={{ sx: { borderRadius: 2 } }}
                name="projectNumber"
                value={projectNumber}
                required
              />
              <TextField
                label="Die name"
                variant="outlined"
                sx={{
                  width: '300px',
                  '& .MuiOutlinedInput-root': { height: '50px' },
                }}
                InputProps={{ sx: { borderRadius: 2 } }}
                name="dieName"
                value={dieName}
                required
              />
              <TextField
                label="Die number"
                variant="outlined"
                sx={{
                  width: '300px',
                  '& .MuiOutlinedInput-root': { height: '50px' },
                }}
                InputProps={{ sx: { borderRadius: 2 } }}
                name="dieNumber"
                value={dieNumber}
                required
              />
              <TextField
                label="Project type"
                variant="outlined"
                sx={{
                  width: '300px',
                  '& .MuiOutlinedInput-root': { height: '50px' },
                }}
                InputProps={{ sx: { borderRadius: 2 } }}
                name="projectType"
                value={projectType}
                required
              />

              <div className="projectDetails">
                <TextField
                  label="Select PO document"
                  variant="outlined"
                  sx={{
                    width: '300px',
                    '& .MuiOutlinedInput-root': { height: '50px' },
                  }}
                  value={projectPOLink?.name || ''}
                  readOnly
                />

                <div className="uploadContainer">
                  <input
                    type="file"
                    name="projectPOLink"
                    style={{ border: 'none', padding: '0' }}
                    className="file-ip"
                  />
                  <LuUpload
                    style={{ fontSize: '1rem' }}
                    className="uploadbtn"
                  />
                </div>
              </div>

              <div className="projectDetails">
                <TextField
                  label="Select design document"
                  variant="outlined"
                  sx={{
                    width: '300px',
                    '& .MuiOutlinedInput-root': { height: '50px' },
                  }}
                  value={projectDesignDocLink?.name || ''}
                  readOnly
                />
                <div className="uploadContainer">
                  <input
                    type="file"
                    name="projectDesignDocLink"
                    style={{ border: 'none' }}
                    className="file-ip"
                  />
                  <LuUpload className="uploadbtn" />
                </div>
              </div>

              <LocalizationProvider dateAdapter={AdapterDayjs}>
                <DatePicker
                  label="Start Date"
                  value={dayjs(startDate)}
                  renderInput={(params) => (
                    <TextField
                      {...params}
                      sx={{
                        width: '300px',
                        '& .MuiInputBase-input': {
                          height: '50px',
                          fontSize: '1rem',
                        },
                      }}
                    />
                  )}
                  required
                />
              </LocalizationProvider>

              <LocalizationProvider dateAdapter={AdapterDayjs}>
                <DatePicker
                  label="End Date"
                  value={dayjs(endDate)}
                  renderInput={(params) => (
                    <TextField
                      {...params}
                      sx={{
                        width: '300px',
                        '& .MuiInputBase-input': {
                          height: '50px',
                          fontSize: '1rem',
                        },
                      }}
                    />
                  )}
                  required
                />
              </LocalizationProvider>

              <FormControl>
                <InputLabel id="status-label">Project Status</InputLabel>
                <Select
                  sx={{ width: '200px' }}
                  labelId="status-label"
                  id="status"
                  name="projectStatus"
                  value={projectStatus}
                  required
                  label="Project Status"
                >
                  <MenuItem value="">
                    <em>None</em>
                  </MenuItem>
                  <MenuItem value="Pending">Pending</MenuItem>
                  <MenuItem value="Completed">Completed</MenuItem>
                  <MenuItem value="Overdue">Overdue</MenuItem>
                </Select>
              </FormControl>
            </div>
          </form>
        </div>
        <TableComponent
          columns={columns}
          rows={stages}
          linkBasePath={'myStage'}
          optionLinkBasePath={'updateStage'}
        />
      </div>
    </section>
  )
}

export default MyProject
