import React, { useState, useEffect, useMemo } from 'react'
import './../AddProject/AddProject.css'
import { useDispatch, useSelector } from 'react-redux'
import {
  fetchProjectById,
  fetchProjects,
  fetchStages,
  updateProject,
  updateStage,
} from '../../../features/projectSlice.js'
import { useNavigate, useParams } from 'react-router-dom'
import { formatDate } from '../../common/functions/formatDate.js'
import ProjectForm from '../common/ProjectForm.jsx'
import AddStage from '../AddStage/AddStage.jsx'

import { FaRegArrowAltCircleLeft } from 'react-icons/fa'
import { FiSave } from 'react-icons/fi'

const UpdateProject = () => {
  const params = useParams()
  const pNo = params.id
  const dispatch = useDispatch()

  const { project = {}, stages = [] } = useSelector((state) => state.projects)

  const [inputValues, setInputValues] = useState({
    projectNumber: '',
    companyName: '',
    dieName: '',
    dieNumber: '',
    projectStatus: '',
    startDate: '',
    endDate: '',
    projectType: '',
    projectPOLink: '',
    projectDesignDocLink: '',
    projectCreatedBy: 'John Doe',
  })
  const navigate = useNavigate('/')
  const [stage, setStage] = useState([])
  const [originalStages, setOriginalStages] = useState([])

  useEffect(() => {
    dispatch(fetchProjectById(pNo))
    dispatch(fetchStages(pNo))
    dispatch(fetchProjects())
  }, [dispatch, pNo])

  const currStages = useMemo(() => {
    return stages && stages.filter((stage) => stage.historyOf == null)
  }, [stages])

  useEffect(() => {
    if (project) {
      setInputValues({
        ...project,
      })
    }
  }, [project])

  useEffect(() => {
    if (currStages.length > 0) {
      setStage(
        currStages.map((s) => ({
          ...s,
        }))
      )
      setOriginalStages(
        currStages.map((s) => ({
          ...s,
        }))
      )
    }
  }, [currStages])

  const handleSave = (e) => {
    e.preventDefault()

    dispatch(updateProject({ id: pNo, data: inputValues }))

    stage.forEach((s, index) => {
      const originalStage = originalStages[index]
      console.log({ s: { ...s } })
      console.log({ originalStage: { ...originalStage } })

      if (hasChanges(s, originalStage)) {
        dispatch(updateStage({ ...s, projectNumber: pNo }))
      }
    })

    navigate('/')
  }

  const hasChanges = (stage, originalStage) => {
    return Object.keys(stage).some((key) => stage[key] !== originalStage[key])
  }

  return (
    <>
      <section className="addProject">
        <form className="addForm" onSubmit={handleSave}>
          <div className="beforeForm">
            <p>
              <FaRegArrowAltCircleLeft
                className="back"
                onClick={() => history.back()}
              />
              <span>
                Dashboard <span>/</span>
              </span>
              Update Project
            </p>
            <button type="submit" className="save">
              <FiSave />
              <p>Save project</p>
            </button>
          </div>
          <div className="formDiv">
            <ProjectForm
              inputValues={inputValues}
              setInputValues={setInputValues}
            />
            <AddStage stages={stage} setStages={setStage} />
          </div>
        </form>
      </section>
    </>
  )
}

export default UpdateProject
