import React from 'react'
import '../AddProject/AddProject.css'
import { LuUpload } from 'react-icons/lu'
import TextField from '@mui/material/TextField'
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs'
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider'
import { DatePicker } from '@mui/x-date-pickers/DatePicker'
import dayjs from 'dayjs'
import { FormControl, InputLabel, MenuItem, Select } from '@mui/material'

const ProjectForm = ({ inputValues, setInputValues }) => {
  const handleChange = (e) => {
    const { name, value } = e.target
    setInputValues((prevValues) => ({
      ...prevValues,
      [name]: value,
    }))
  }

  const handleDateChange = (date, fieldName) => {
    setInputValues((prevValues) => ({
      ...prevValues,
      [fieldName]: date ? date.toISOString() : null,
    }))
  }

  const handleFileChange = (e, fieldName) => {
    const file = e.target.files[0]
    setInputValues((prevValues) => ({
      ...prevValues,
      [fieldName]: file,
    }))
  }

  return (
    <>
      <h2>Project details</h2>
      <div className="container">
        <TextField
          label="Company name"
          variant="outlined"
          sx={{
            width: '300px',
            '& .MuiOutlinedInput-root': { height: '50px' },
          }}
          InputProps={{ sx: { borderRadius: 2 } }}
          name="companyName"
          value={inputValues.companyName}
          onChange={handleChange}
          required
        />
        <TextField
          label="Project number"
          variant="outlined"
          sx={{
            width: '300px',
            '& .MuiOutlinedInput-root': { height: '50px' },
          }}
          InputProps={{ sx: { borderRadius: 2 } }}
          name="projectNumber"
          value={inputValues.projectNumber}
          onChange={handleChange}
          required
        />
        <TextField
          label="Die name"
          variant="outlined"
          sx={{
            width: '300px',
            '& .MuiOutlinedInput-root': { height: '50px' },
          }}
          InputProps={{ sx: { borderRadius: 2 } }}
          name="dieName"
          value={inputValues.dieName}
          onChange={handleChange}
          required
        />
        <TextField
          label="Die number"
          variant="outlined"
          sx={{
            width: '300px',
            '& .MuiOutlinedInput-root': { height: '50px' },
          }}
          InputProps={{ sx: { borderRadius: 2 } }}
          name="dieNumber"
          value={inputValues.dieNumber}
          onChange={handleChange}
          required
        />
        <TextField
          label="Project type"
          variant="outlined"
          sx={{
            width: '300px',
            '& .MuiOutlinedInput-root': { height: '50px' },
          }}
          InputProps={{ sx: { borderRadius: 2 } }}
          name="projectType"
          value={inputValues.projectType}
          onChange={handleChange}
          required
        />

        <div className="projectDetails">
          <TextField
            label="Select PO document"
            variant="outlined"
            sx={{
              width: '300px',
              '& .MuiOutlinedInput-root': { height: '50px' },
            }}
            value={inputValues.projectPOLink?.name || ''} // Display file name if file is selected
            readOnly
          />

          <div className="uploadContainer">
            <input
              type="file"
              name="projectPOLink"
              style={{ border: 'none', padding: '0' }}
              className="file-ip"
              onChange={(e) => handleFileChange(e, 'projectPOLink')}
            />
            <LuUpload style={{ fontSize: '1rem' }} className="uploadbtn" />
          </div>
        </div>

        <div className="projectDetails">
          <TextField
            label="Select design document"
            variant="outlined"
            sx={{
              width: '300px',
              '& .MuiOutlinedInput-root': { height: '50px' },
            }}
            value={inputValues.projectDesignDocLink?.name || ''} // Display file name if file is selected
            readOnly
          />
          <div className="uploadContainer">
            <input
              type="file"
              name="projectDesignDocLink"
              style={{ border: 'none' }}
              className="file-ip"
              onChange={(e) => handleFileChange(e, 'projectDesignDocLink')}
            />
            <LuUpload className="uploadbtn" />
          </div>
        </div>

        <LocalizationProvider dateAdapter={AdapterDayjs}>
          <DatePicker
            label="Start Date"
            value={dayjs(inputValues.startDate)} // Ensure value is a valid Dayjs object
            onChange={(date) => handleDateChange(date, 'startDate')}
            renderInput={(params) => (
              <TextField
                {...params}
                sx={{
                  width: '300px',
                  '& .MuiInputBase-input': { height: '50px', fontSize: '1rem' },
                }}
              />
            )}
            required
          />
        </LocalizationProvider>

        <LocalizationProvider dateAdapter={AdapterDayjs}>
          <DatePicker
            label="End Date"
            value={dayjs(inputValues.endDate)} // Ensure value is a valid Dayjs object
            onChange={(date) => handleDateChange(date, 'endDate')}
            renderInput={(params) => (
              <TextField
                {...params}
                sx={{
                  width: '300px',
                  '& .MuiInputBase-input': { height: '50px', fontSize: '1rem' },
                }}
              />
            )}
            required
          />
        </LocalizationProvider>

        <FormControl>
          <InputLabel id="status-label">Project Status</InputLabel>
          <Select
            sx={{ width: '200px' }}
            labelId="status-label"
            id="status"
            name="projectStatus"
            value={inputValues.projectStatus}
            onChange={handleChange}
            required
            label="Project Status"
          >
            <MenuItem value="">
              <em>None</em>
            </MenuItem>
            <MenuItem value="Pending">Pending</MenuItem>
            <MenuItem value="Completed">Completed</MenuItem>
            <MenuItem value="Overdue">Overdue</MenuItem>
          </Select>
        </FormControl>
      </div>
    </>
  )
}

export default ProjectForm
