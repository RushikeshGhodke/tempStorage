import { createAsyncThunk, createSlice } from '@reduxjs/toolkit'
import api from '../api/api.js'

export const fetchProjects = createAsyncThunk(
  'projects/fetchProjects',
  async () => {
    const response = await api.get(`/projects`)
    console.log(response)
    return response.data
  }
)

export const fetchProjectById = createAsyncThunk(
  'projects/fetchProjectById',
  async (id = '') => {
    const response = await api.get(`/projects/${id}`)
    console.log(response)
    return response.data
  }
)

export const fetchStages = createAsyncThunk(
  'stages/fetchStages',
  async (id = '') => {
    const response = await api.get(`/stages/${id}`)
    return response.data.data
  }
)

export const updateProject = createAsyncThunk(
  'stages/updateProject',
  async ({ id = '', data = {} }) => {
    const response = await api.put(`/projects/${id}`, data)
    return response.data.data
  }
)

export const updateStage = createAsyncThunk('stages/updateStage', async (s) => {
  const response = await api.put(`/stages/${s.stageId}`, s)
  return response.data.data
})

export const addProject = createAsyncThunk(
  'projects/addProject',
  async (project) => {
    const response = await api.post('/projects', project)
    return response.data.data
  }
)

export const deleteStage = createAsyncThunk(
  'projects/deleteStage',
  async (id = '') => {
    const response = await api.get(`/stages/${id}`)
    return response.data.data
  }
)

export const deleteProject = createAsyncThunk(
  'projects/deleteProject',
  async (id = '') => {
    const response = await api.delete(`/projects/${id}`)
    return response.data.data
  }
)

export const fetchStageById = createAsyncThunk(
  'stage/fetchStageById',
  async (id = '') => {
    const response = await api.get(`/stages/${id}`)
    return response.data
  }
)

const initialState = {
  projects: [],
  project: {},
  stages: [],
  stage: {},
  status: 'idle',
  error: null,
  loading: false,
}

const projectsSlice = createSlice({
  name: 'projects',
  initialState: initialState,
  reducers: {
    clearProjectsStatus: (state) => {
      state.status = null
    },
    clearProjectsError: (state) => {
      state.error = null
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(addProject.pending, (state) => {
        state.loading = true
      })
      .addCase(addProject.fulfilled, (state, action) => {
        console.log(action)
        state.loading = false
        state.projects.push(action.payload)
        state.status = 'succeeded'
      })
      .addCase(addProject.rejected, (state, action) => {
        console.log(action)
        state.loading = false
        state.status = 'failed'
        state.error = action.error.message
      })
      .addCase(fetchProjects.pending, (state) => {
        state.loading = true
      })
      .addCase(fetchProjects.fulfilled, (state, action) => {
        state.loading = false
        console.log(action)
        state.projects = action.payload.data
        state.status = action.payload.message
      })
      .addCase(fetchProjects.rejected, (state, action) => {
        state.loading = false
        console.log(action)
        state.status = 'failed'
        state.error = action.error.message
      })
      .addCase(deleteProject.pending, (state) => {
        state.loading = true
      })
      .addCase(deleteProject.fulfilled, (state, action) => {
        state.loading = false
        state.projects = state.projects.filter(
          (project) => project.projectNumber != action.payload
        )
        state.status = 'succeeded'
      })
      .addCase(deleteProject.rejected, (state, action) => {
        state.loading = false
        state.status = 'failed'
        console.log(action)
        state.error = action.error.message
      })
      .addCase(fetchProjectById.pending, (state) => {
        state.loading = true
      })
      .addCase(fetchProjectById.fulfilled, (state, action) => {
        state.loading = false
        state.project = action.payload.data
        state.status = action.payload.message
      })
      .addCase(fetchProjectById.rejected, (state, action) => {
        state.loading = false
        state.status = 'failed'
        console.log(action)
        state.error = action.error.message
      })
      .addCase(fetchStages.pending, (state) => {
        state.loading = true
        state.status = 'loading'
      })
      .addCase(fetchStages.fulfilled, (state, action) => {
        state.loading = false
        state.status = 'succeeded'
        state.stages = action.payload
      })
      .addCase(fetchStages.rejected, (state, action) => {
        state.loading = false
        state.status = 'failed'
        console.log(action)
        state.error = action.error.message
      })
      .addCase(updateProject.pending, (state) => {
        state.loading = true
      })
      .addCase(updateProject.fulfilled, (state, action) => {
        state.loading = false
        state.status = 'succeeded'
        console.log('state')
        console.log(...state.projects)
        const index = state.projects.findIndex(
          (project) => project.projectNumber === action.payload.projectNumber
        )
        console.log(action.payload)

        state.projects[index] = action.payload
        state.project = action.payload
      })
      .addCase(updateProject.rejected, (state, action) => {
        state.loading = false
        state.status = 'failed'
        console.log(action)
        state.error = action.error.message
      })
      .addCase(updateStage.pending, (state) => {
        state.loading = true
        state.status = 'loading'
      })
      .addCase(updateStage.fulfilled, (state, action) => {
        state.loading = false
        state.status = 'succeeded'
        const index = state.stages.findIndex(
          (stage) => stage.stageId == action.payload.stageId
        )
        state.stages[index] = action.payload
      })
      .addCase(updateStage.rejected, (state, action) => {
        state.loading = false
        state.status = 'failed'
        console.log(action)
        state.error = action.error.message
      })
      .addCase(deleteStage.pending, (state) => {
        state.loading = true
      })
      .addCase(deleteStage.fulfilled, (state, action) => {
        state.loading = false
        state.stages = state.stages.filter(
          (stage) => stage.stageId != action.payload.stageId
        )
        state.status = 'succeeded'
      })
      .addCase(deleteStage.rejected, (state, action) => {
        state.loading = false
        console.log(action)
        state.error = action.error.message
      })
      .addCase(fetchStageById.pending, (state) => {
        state.loading = true
      })
      .addCase(fetchStageById.fulfilled, (state, action) => {
        state.loading = false
        state.stage = action.payload.data
        state.status = action.payload.message
      })
      .addCase(fetchStageById.rejected, (state, action) => {
        state.loading = false
        state.status = 'failed'
        console.log(action)
        state.error = action.error.message
      })
  },
})

export const projectsReducer = projectsSlice.reducer
export const { clearProjectsStatus, clearProjectsError } = projectsSlice.actions
