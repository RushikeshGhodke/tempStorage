import { BrowserRouter, Routes, Route } from 'react-router-dom'
import Navbar from './components/common/Navbar/Navbar'
import Sidebar from './components/common/Sidebar/Sidebar'
import MyProject from './components/Project/MyProject/MyProject'
import AddProject from './components/Project/AddProject/AddProject'
import AllProjects from './components/Project/AllProjects/AllProjects'
import Loader from './components/common/loader/Loader'
import UpdateProject from './components/Project/UpdateProject/UpdateProject'
import AddSubStage from './components/Project/AddSubstages/AddSubStage'
function App() {
  return (
    <>
      <BrowserRouter>
        <Navbar />
        <Sidebar />
        <Routes>
          <Route path="/" element={<AllProjects />} />
          <Route path="/addProject" element={<AddProject />} />
          <Route path="/myProject/:id" element={<MyProject />} />
          <Route path="/updateProject/:id" element={<UpdateProject />} />
          <Route path="/updateStage/:id" element={<AddSubStage />} />
          <Route path="/load" element={<Loader />} />
        </Routes>
      </BrowserRouter>
    </>
  )
}

export default App
