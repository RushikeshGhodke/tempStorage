import React, { useState, useMemo, useEffect } from 'react'
import {
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Collapse,
  Typography,
  Box,
  TablePagination,
  TableSortLabel,
  IconButton,
} from '@mui/material'
import { Link, Navigate, useNavigate } from 'react-router-dom'
import { v4 as uuidv4 } from 'uuid'
import { useDispatch } from 'react-redux'
import { FiEdit2 } from 'react-icons/fi'
import { FaRegClock } from 'react-icons/fa'
import { RiDeleteBinLine } from 'react-icons/ri'
import './TableComponent.css'
import { deleteProject, deleteStage } from '../features/projectSlice'
import { formatDate } from '../components/common/functions/formatDate'

const TableComponent = ({
  rows,
  columns,
  linkBasePath,
  optionLinkBasePath,
}) => {
  const formattedRows = useMemo(
    () =>
      rows.map((row) => ({
        ...row,
        startDate: formatDate(row.startDate),
        endDate: formatDate(row.endDate),
      })),
    [rows]
  )

  const dispatch = useDispatch()
  const [page, setPage] = useState(0)
  const [rowsPerPage, setRowsPerPage] = useState(10)

  const [order, setOrder] = useState('asc')
  const [orderBy, setOrderBy] = useState('')
  const navigate = useNavigate()

  const handleChangePage = (event, newPage) => {
    setPage(newPage)
  }

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(+event.target.value)
    setPage(0)
  }

  const handleRequestSort = (property) => {
    const isAsc = orderBy === property && order === 'asc'
    setOrder(isAsc ? 'desc' : 'asc')
    setOrderBy(property)
  }

  const stableSort = (array, comparator) => {
    const stabilizedThis = array.map((el, index) => [el, index])
    stabilizedThis.sort((a, b) => {
      const order = comparator(a[0], b[0])
      if (order !== 0) return order
      return a[1] - b[1]
    })
    return stabilizedThis.map((el) => el[0])
  }

  const getComparator = (order, orderBy) => {
    return order === 'desc'
      ? (a, b) => descendingComparator(a, b, orderBy)
      : (a, b) => -descendingComparator(a, b, orderBy)
  }

  const descendingComparator = (a, b, orderBy) => {
    if (b[orderBy] < a[orderBy]) {
      return -1
    }
    if (b[orderBy] > a[orderBy]) {
      return 1
    }
    return 0
  }

  const [open, setOpen] = useState([])
  const handleClick = (clickIndex) => {
    if (open.includes(clickIndex)) {
      const openCopy = open.filter((element) => element !== clickIndex)
      setOpen(openCopy)
    } else {
      const openCopy = [...open]
      openCopy.push(clickIndex)
      setOpen(openCopy)
    }
  }

  return (
    <Paper className="table-container">
      <TableContainer className="custom-scrollbar">
        <Table aria-label="data table">
          <TableHead>
            <TableRow>
              <TableCell
                key="serialNo"
                align="left"
                sx={{
                  fontWeight: 'bold',
                  backgroundColor: '#FFFFFF',
                  color: '#002773',
                  fontSize: '16px',
                  textAlign: 'left',
                  fontFamily: 'Inter, sans-serif',
                  position: 'sticky',
                  top: 0,
                  zIndex: 1,
                }}
              >
                Sr. No.
              </TableCell>
              {columns.map((column) => (
                <TableCell
                  key={column.id}
                  align={column.align}
                  sx={{
                    fontWeight: 'bold',
                    backgroundColor: '#FFFFFF',
                    color: '#002773',
                    fontSize: '16px',
                    textAlign: 'left',
                    fontFamily: 'Inter, sans-serif',
                    position: 'sticky',
                    top: 0,
                    zIndex: 1,
                  }}
                  sortDirection={orderBy === column.id ? order : false}
                >
                  <TableSortLabel
                    active={orderBy === column.id}
                    direction={orderBy === column.id ? order : 'asc'}
                    onClick={() => handleRequestSort(column.id)}
                  >
                    {column.label}
                  </TableSortLabel>
                </TableCell>
              ))}
              <TableCell
                align="center"
                sx={{
                  fontWeight: 'bold',
                  backgroundColor: '#FFFFFF',
                  color: '#002773',
                  fontSize: '16px',
                  fontFamily: 'Inter, sans-serif',
                  position: 'sticky',
                  top: 0,
                  zIndex: 1,
                }}
              ></TableCell>
            </TableRow>
          </TableHead>

          <TableBody>
            {stableSort(formattedRows, getComparator(order, orderBy))
              .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
              .map(
                (row, index) =>
                  row.historyOf == null && (
                    <>
                      <TableRow
                        key={uuidv4()}
                        sx={{
                          cursor: linkBasePath ? 'pointer' : 'default',
                          textDecoration: 'none',
                        }}
                        className="table-row "
                      >
                        <TableCell
                          sx={{
                            textAlign: 'left',
                            fontFamily: 'Inter, sans-serif',
                            textDecoration: 'none',
                          }}
                          component={linkBasePath ? Link : 'tr'}
                          to={
                            linkBasePath
                              ? `${linkBasePath}/${
                                  row.empId || row.deptId || row.projectNumber
                                }`
                              : undefined
                          }
                          align="center"
                        >
                          {page * rowsPerPage + index + 1}
                        </TableCell>
                        {columns.map((column) => (
                          <TableCell
                            key={uuidv4()}
                            sx={{
                              textAlign: 'left',
                              fontFamily: 'Inter, sans-serif',
                              textDecoration: 'none',
                              cursor: 'pointer',
                            }}
                            component={linkBasePath ? Link : 'td'}
                            to={
                              linkBasePath
                                ? `${linkBasePath}/${
                                    row.empId || row.deptId || row.projectNumber
                                  }`
                                : undefined
                            }
                            align={column.align}
                          >
                            {row[column.id]}
                          </TableCell>
                        ))}
                        <TableCell
                          sx={{
                            fontFamily: 'Inter, sans-serif',
                            cursor: 'pointer',
                            paddingLeft: '0',
                            paddingRight: '0',
                          }}
                          id="options"
                        >
                          <Link
                            to={
                              optionLinkBasePath
                                ? `${optionLinkBasePath}/${
                                    row.empId || row.deptId || row.projectNumber
                                  }`
                                : undefined
                            }
                            replace
                          >
                            <IconButton>
                              <FiEdit2 className="option-icon" />
                            </IconButton>
                          </Link>
                          {row.stageId && (
                            <IconButton onClick={() => handleClick(index)}>
                              <FaRegClock className="option-icon" />
                            </IconButton>
                          )}
                          <IconButton
                            onClick={() =>
                              row.projectNumber
                                ? window.confirm(
                                    `Are you sure you want to delete project ${row.projectNumber}`
                                  ) &&
                                  dispatch(deleteProject(row.projectNumber))
                                : row.stageId
                                ? window.confirm(
                                    `Are you sure you want to delete stage ${row.stageId}`
                                  ) && dispatch(deleteStage(row.stageId))
                                : ''
                            }
                          >
                            <RiDeleteBinLine className="option-icon" />
                          </IconButton>

                          {console.log(
                            stableSort(
                              formattedRows,
                              getComparator(order, orderBy)
                            ).slice(
                              page * rowsPerPage,
                              page * rowsPerPage + rowsPerPage
                            )
                          )}
                        </TableCell>
                      </TableRow>

                      <TableRow className="historyOfStages">
                        <TableCell
                          style={{ paddingBottom: 0, paddingTop: 0 }}
                          colSpan={columns.length + 2}
                        >
                          <Collapse
                            in={open.includes(index)}
                            timeout="auto"
                            unmountOnExit
                          >
                            <Box margin={1}>
                              <Typography variant="h6" gutterBottom>
                                Stage history
                              </Typography>
                              <Typography variant="body1">
                                <table className="history-table">
                                  <thead>
                                    <tr>
                                      {columns.map((column) => {
                                        return <td>{column.label}</td>
                                      })}
                                    </tr>
                                  </thead>
                                  <tbody>
                                    {stableSort(
                                      formattedRows,
                                      getComparator(order, orderBy)
                                    )
                                      .filter(
                                        (hs) => hs.historyOf === row.stageId
                                      )
                                      .map((hs) => (
                                        <tr key={uuidv4()}>
                                          {columns.map((column) => (
                                            <td key={uuidv4()}>
                                              {hs[column.id]}
                                            </td>
                                          ))}
                                        </tr>
                                      ))}
                                  </tbody>
                                </table>
                              </Typography>
                            </Box>
                          </Collapse>
                        </TableCell>
                      </TableRow>
                    </>
                  )
              )}
          </TableBody>
        </Table>
      </TableContainer>
      <TablePagination
        component="div"
        count={formattedRows.length}
        page={page}
        onPageChange={handleChangePage}
        rowsPerPage={rowsPerPage}
        onRowsPerPageChange={handleChangeRowsPerPage}
        rowsPerPageOptions={[10, 25, 50]}
      />
    </Paper>
  )
}

export default TableComponent
